# Zombs.exe

Zombs.exe is a game inspired by Zombs.io

The initial goal was to do a remake, but I changed some gameplay
It's only single player and the world is limited to the size of the window

The game is not finished, I need to do the waves (waves.json)

![Title image](https://github.com/Guigui220D/zombs.exe/blob/master/screenshots/newer.PNG)
